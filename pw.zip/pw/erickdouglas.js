let nome = prompt("Digite seu Nome:");
let data = prompt("Digite Seu ano que vc nasceu: ")
const x = 2026 - data
alert(`Você tem ${x} anos, ${nome}.`);